package com.nic.tip

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.util.Log
import android.widget.Spinner
import android.widget.*
import android.icu.text.NumberFormat
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener {


    private val currency = NumberFormat.getCurrencyInstance()
    private var tipPercent = 0.0



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val editAmnt: EditText = findViewById(R.id.editAmnt)
        val yourTotal = findViewById<TextView>(R.id.yourTotal)
        val tipAmnt = findViewById<TextView>(R.id.tipAmnt)
        val Cbutton = findViewById<Button>(R.id.calcButton)
        val spinner: Spinner = findViewById(R.id.SpinTipAmount)
        spinner.onItemSelectedListener = this


        ArrayAdapter.createFromResource(
            this,
            R.array.tipPercents,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            // Specify the layout to use when the list of choices appears
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            // Apply the adapter to the spinner
            spinner.adapter = adapter
            spinner.onItemSelectedListener = this
            Log.d("GETS TO HERE","Gets to here")
        }



        Cbutton.setOnClickListener{
            if (editAmnt.text.toString().trim().isNotEmpty() ){
                var Camount = editAmnt.text.toString().toDouble()
                var tipAmount= Camount * tipPercent
                var tTotal = Camount + tipAmount

                yourTotal.text = currency.format(tTotal).toString()
                tipAmnt.text = currency.format(tipAmount).toString()

            }
        }
    }








    override fun onNothingSelected(p0: AdapterView<*>?) {
        Log.d("UNIQUETAG", "Nothing Selected")
    }

    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
        Log.d("UNIQUETAG", "Index $p2 was selected")
        Log.wtf("Error", "Yes, you have an error")
        when (p2)
        {
            1 -> tipPercent = .1
            2 -> tipPercent = .15
            3 -> tipPercent = .2

        }

        Log.wtf("TipPercent", "The tip percent is $tipPercent")
    }


}
